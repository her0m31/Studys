package pot;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ModeLamp extends JPanel {
    private static final int high_xpoints[]    = { 20,   5,  35};
    private static final int economy_xpoints[] = { 60,  45,  75};
    private static final int milk_xpoints[]    = {100,  85, 115};
    private static final int high_ypoints[]    = { 39,  15,  15};
    private static final int economy_ypoints[] = { 39,  15,  15};
    private static final int milk_ypoints[]    = { 39,  15,  15};

    private Color off;
    private Color on;
    private boolean high;
    private boolean economy;
    private boolean milk;

    ModeLamp() {
        this(Color.lightGray, Color.green, false, false, false);
    }

    ModeLamp(Color off, Color on, boolean high, boolean economy, boolean milk) {
        this.off     = off;
        this.on      = on;
        this.high    = high;
        this.economy = economy;
        this.milk    = milk;

        setMinimumSize(new Dimension(120, 30));
    }

    void setHigh(boolean bool) {
        high = bool;
    }

    void setEconomy(boolean bool) {
        economy = bool;
    }

    void setMilk(boolean bool) {
        milk = bool;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(off);
        g.fillPolygon(high_xpoints, high_ypoints, 3);
        g.fillPolygon(economy_xpoints, economy_ypoints, 3);
        g.fillPolygon(milk_xpoints, milk_ypoints, 3);

        g.setColor(on);
        if (high) {
            g.fillPolygon(high_xpoints, high_ypoints, 3);
        }
        if (economy) {
            g.fillPolygon(economy_xpoints, economy_ypoints, 3);
        }
        if (milk) {
            g.fillPolygon(milk_xpoints, milk_ypoints, 3);
        }
    }
}
