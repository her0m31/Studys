package pot;

class Thermistor implements Runnable {
    private double              water_temperature; // ����
    private boolean             heater;            // �q�[�^
    private boolean             heater_power;      // �q�[�^�p�d��
    private Pot                 pot;

    Thermistor(Pot p) {
        pot               = p;
        water_temperature = 20; // �����Ă��鐅�̉��x��20�ŌŒ肷��
        heater            = false;
        heater_power      = true;

        Thread t = new Thread(this);
        t.start();
    }

    double getWaterTemperature() {
        if (water_temperature < -10) {
            return -10;
        }
        if (water_temperature > 150) {
            return 150;
        }
        return water_temperature;
    }

    boolean getHeater() {
        return heater;
    }

    boolean getHeaterPower() {
        return heater_power;
    }

    void setHeater(boolean bool) {
        heater = bool;
    }

    public void run() {
        double old_pondage = pot.getPondage();
        while(true) {
            if (pot.getPondage() == 0) {
                water_temperature = 0;
            }
            else if (old_pondage < pot.getPondage()) {
                water_temperature = ((20 * (pot.getPondage() - old_pondage)) + (water_temperature * old_pondage))
                                    / pot.getPondage();
            }
            else if (heater_power && heater) {
                if (water_temperature <= 100) {
                    water_temperature += 500.0 / pot.getPondage();
                }
		if (water_temperature > 100) {
		    water_temperature = 100;
		}
            }
            else {
                if (water_temperature >= 20) {
                    water_temperature -= 100.0 / pot.getPondage();
                }
		if (water_temperature < 20) {
		    water_temperature = 20;
		}
            }

            old_pondage = pot.getPondage();

            try {
                Thread.sleep(500);
            }
            catch (Exception e) {
                System.err.println(e);
            }
        }
    }
}
