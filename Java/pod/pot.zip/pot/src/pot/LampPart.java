package pot;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class LampPart extends JPanel {
    private Color   before;
    private Color   after;
    private boolean on;

    LampPart() {
        this(Color.lightGray, Color.green);
    }

    LampPart(Color after) {
        this(Color.lightGray, after);
    }

    LampPart(Color before, Color after) {
        this.before = before;
        this.after  = after;
        this.on     = false;
    }

    void setLamp(boolean bool) {
        on = bool;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (on) {
            g.setColor(after);
        }
        else {
            g.setColor(before);
        }
        g.fillOval(0, 0, 10, 10);
    }
}
