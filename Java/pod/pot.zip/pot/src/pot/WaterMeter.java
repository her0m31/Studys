package pot;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class WaterMeter extends JPanel {
    private WaterMeterLamp lamp;

    WaterMeter() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        lamp = new WaterMeterLamp();

        setMinimumSize(new Dimension(40, 130));
        setSize(40, 130);

        add(new JLabel("����"));
        add(lamp);
    }

    void setSensor(int sensor_no, boolean bool) {
        lamp.setSensor(sensor_no, bool);
    }
}
