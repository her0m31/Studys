package pot;

import java.io.*;

public class Pot {
    WaterLevelDetecting water_level; // ���ʌ��o��
    Thermistor          thermistor;  // ���M��
    Control             control;


    public Pot() {
        water_level = new WaterLevelDetecting(0.0);
        thermistor  = new Thermistor(this);
        control     = new Control(this);
    }

    public void putWater(double water_dosage) {
        if (getLidSensor()) {
            return;
        }
        water_level.putWater(water_dosage);
    }

    public void hotWaterSupply(double water_dosage) {
        water_level.pushWater(water_dosage);
    }

    public boolean getWaterLevelSensor1() {
        return water_level.getWaterLevelSensor1();
    }

    public boolean getWaterLevelSensor2() {
        return water_level.getWaterLevelSensor2();
    }

    public boolean getWaterLevelSensor3() {
        return water_level.getWaterLevelSensor3();
    }

    public boolean getWaterLevelSensor4() {
        return water_level.getWaterLevelSensor4();
    }

    public boolean getFullWaterSensor() {
        return water_level.getFullWaterSensor();
    }

    // ���M��
    public double getWaterTemperature() {
        return thermistor.getWaterTemperature();
    }

    public boolean getHeater() {
        return thermistor.getHeater();
    }

    public boolean getHeaterPower() {
        return thermistor.getHeaterPower();
    }

    public void setHeater(boolean bool) {
        thermistor.setHeater(bool);
    }


    public int getMode() {
        return control.getMode();
    }

    public boolean getBoiling() {
        return control.getBoiling();
    }

    public boolean getHotWaterSupply() {
        return control.getHotWaterSupply();
    }

    public boolean getRelease() {
        return control.getRelease();
    }

    public boolean getLidSensor() {
        return control.getLidSensor();
    }

    public void setTemperature(String temperature) {
        control.setTemperature(temperature);
    }

    public void setRemainingTime(String time) {
        control.setRemainingTime(time);
    }

    public void setBoilingLamp(boolean bool) {
        control.setBoilingLamp(bool);
    }

    public void setKeepWarmLamp(boolean bool) {
        control.setKeepWarmLamp(bool);
    }

    public void setLockLamp(boolean bool) {
        control.setLockLamp(bool);
    }

    public void setHigh(boolean bool) {
        control.setHigh(bool);
    }

    public void setEconomy(boolean bool) {
        control.setEconomy(bool);
    }

    public void setMilk(boolean bool) {
        control.setMilk(bool);
    }

    public void setWaterMeter1(boolean bool) {
        control.setWaterMeter1(bool);
    }

    public void setWaterMeter2(boolean bool) {
        control.setWaterMeter2(bool);
    }

    public void setWaterMeter3(boolean bool) {
        control.setWaterMeter3(bool);
    }

    public void setWaterMeter4(boolean bool) {
        control.setWaterMeter4(bool);
    }

    public boolean getTimer() {
        return control.getTimer();
    }

    public double getPondage() {
        return water_level.getPondage();
    }


}