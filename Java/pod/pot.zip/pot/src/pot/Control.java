package pot;

import javax.swing.*;


import java.awt.*;
import java.awt.event.*;

class Control extends JFrame
              implements MouseListener, Runnable {
    private int     mode;
    private boolean boiling;
    private boolean hot_water_supply;
    private boolean release;
    private boolean timer;
    private boolean lid_sensor;
    private boolean is_pour_water;

    private Pot pot;

    private Container  content_pane;
    private JButton    keep_warm_setting_button; // �ۉ��ݒ�{�^��
    private JButton    boiling_button;           // �����{�^��
    private JLabel     temperature;              // ���x�\��
    private ModeLamp   mode_lamp;                // ���[�h�\��
    private Lamp       boiling_lamp;             // ���������v
    private Lamp       keep_warm_lamp;           // �ۉ������v

    private JButton    hot_water_supply_button;  // �����{�^��
    private JButton    release_button;           // �����{�^��
    private WaterMeter water_meter;              // ���ʃ��[�^
    private Lamp       lock_lamp;                // ���b�N�����v

    private JButton    timer_button;             // �^�C�}�{�^��
    private JLabel     remaining_time;           // �^�C�}�c�莞�ԕ\����

    private JButton    lid_button;               // �t�^�̊J��
    private JButton    pour_water_button;        // ���𒍂�

    Control(Pot p) {
        super("�R���g���[��");

        mode = 0;
        pot  = p;

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(200, 850);
        content_pane = getContentPane();

        keep_warm_lamp = new Lamp("�ۉ�");
        boiling_lamp   = new Lamp("����");
        lock_lamp      = new Lamp("���b�N");

        mode_lamp = new ModeLamp();

        temperature = new JLabel();
	temperature.setFont(new Font("Dialog", Font.BOLD, 40));

        water_meter = new WaterMeter();

        remaining_time = remainingTime("");

        keep_warm_setting_button = new JButton("�ۉ��ݒ�");
        keep_warm_setting_button.addMouseListener(this);
        boiling_button = new JButton("����");
        boiling_button.addMouseListener(this);
        hot_water_supply_button = new JButton("����");
        hot_water_supply_button.addMouseListener(this);
        release_button = new JButton("����");
        release_button.addMouseListener(this);
        timer_button = new JButton("�^�C�}");
        timer_button.addMouseListener(this);


        lid_sensor = true;
        lid_button = new JButton("�W���J��");
        lid_button.addMouseListener(this);
        pour_water_button = new JButton("���𒍂�");
        pour_water_button.addMouseListener(this);

        /* �z�u */
        content_pane.setLayout(new BoxLayout(content_pane, BoxLayout.Y_AXIS));
        content_pane.add(keep_warm_setting_button);
        content_pane.add(boiling_button);
        content_pane.add(hot_water_supply_button);
        content_pane.add(release_button);
        content_pane.add(timer_button);
        content_pane.add(keep_warm_lamp);
        content_pane.add(boiling_lamp);
        content_pane.add(lock_lamp);
        content_pane.add(mode_lamp);
        content_pane.add(temperature);
        content_pane.add(water_meter);
        content_pane.add(remaining_time);
        content_pane.add(lid_button);
        content_pane.add(pour_water_button);

        Thread t = new Thread(this);
        t.start();
        setVisible(true);
    }

    int getMode() {
        return mode;
    }

    boolean getBoiling() {
        return boiling;
    }

    boolean getHotWaterSupply() {
        return hot_water_supply;
    }

    boolean getRelease() {
        return release;
    }

    boolean getLidSensor() {
        return lid_sensor;
    }

    boolean getTimer() {
        return timer;
    }

    void setTemperature(String t) {
        temperature.setText(t);
    }

    void setRemainingTime(String time) {
        remaining_time = remainingTime(time);
    }

    private JLabel remainingTime(String time) {
        return new JLabel(time + "��");
    }


    void setBoilingLamp(boolean bool) {
        boiling_lamp.setLamp(bool);
        repaint();
    }

    void setKeepWarmLamp(boolean bool) {
        keep_warm_lamp.setLamp(bool);
        repaint();
    }

    void setLockLamp(boolean bool) {
        lock_lamp.setLamp(bool);
        repaint();
    }

    void setHigh(boolean bool) {
        mode_lamp.setHigh(bool);
        repaint();
    }

    void setEconomy(boolean bool) {
        mode_lamp.setEconomy(bool);
        repaint();
    }

    void setMilk(boolean bool) {
        mode_lamp.setMilk(bool);
        repaint();
    }

    void setWaterMeter1(boolean bool) {
        water_meter.setSensor(1, bool);
        repaint();
    }

    void setWaterMeter2(boolean bool) {
        water_meter.setSensor(2, bool);
        repaint();
    }

    void setWaterMeter3(boolean bool) {
        water_meter.setSensor(3, bool);
        repaint();
    }

    void setWaterMeter4(boolean bool) {
        water_meter.setSensor(4, bool);
        repaint();
    }

    /* �C�x���g���X�i�[ */
    public void mouseClicked(MouseEvent event) {
        if (event.getSource() == keep_warm_setting_button) {
            mode++;
        }
        if (event.getSource() == release_button) {
            release = ! release;
        }
        if (event.getSource() == lid_button) {
            if (lid_sensor) {
                lid_sensor = false;
                lid_button.setText("�W�����");
            }
            else {
                lid_sensor = true;
                lid_button.setText("�W���J��");
            }
        }
    }

    public void mouseEntered(MouseEvent event) {
    }

    public void mouseExited(MouseEvent event) {
    }

    public void mousePressed(MouseEvent event) {
        if (event.getSource() == boiling_button) {
            boiling = true;
        }
        if (event.getSource() == hot_water_supply_button) {
            hot_water_supply = true;
        }
        if (event.getSource() == timer_button) {
            timer = true;
        }
        if (event.getSource() == pour_water_button) {
            if (lid_sensor) {
                ;
            }
            else {
                is_pour_water = true;
            }
        }
    }

    public void mouseReleased(MouseEvent event) {
        if (event.getSource() == boiling_button) {
            boiling = false;
        }
        if (event.getSource() == hot_water_supply_button) {
            hot_water_supply = false;
        }
        if (event.getSource() == pour_water_button) {
            is_pour_water = false;
        }
        if (event.getSource() == timer_button) {
            timer = false;
        }
    }

    public void run() {
        while (true) {
        	System.out.print("");
            while (is_pour_water) {
                pot.putWater(0.000005);
            }
        }
    }
}
