package pot;

class WaterLevelDetecting {
    private double  pondage;                      // ������
    private boolean water_level_sensor_1 = false; // ��1�Z���T�[
    private boolean water_level_sensor_2 = false; // ��2�Z���T�[
    private boolean water_level_sensor_3 = false; // ��3�Z���T�[
    private boolean water_level_sensor_4 = false; // ��4�Z���T�[
    private boolean full_water_sensor    = true;  // �����Z���T�[

    // �R���X�g���N�^
    WaterLevelDetecting(double water) {
        pondage = water;
        checkWater();
    }

    // ���\�b�h
    void putWater(double water) {
        pondage += water;
        checkWater();
    }

    void pushWater(double water) {
        pondage -= water;
        checkWater();
    }

    boolean getWaterLevelSensor1() {
        return water_level_sensor_1;
    }

    boolean getWaterLevelSensor2() {
        return water_level_sensor_2;
    }

    boolean getWaterLevelSensor3() {
        return water_level_sensor_3;
    }

    boolean getWaterLevelSensor4() {
        return water_level_sensor_4;
    }

    boolean getFullWaterSensor() {
        return full_water_sensor;
    }

    double getPondage() {
        return pondage;
    }

    // �v���C�x�[�g���\�b�h
    private void checkWater() {
        if (pondage >= 400) {
            full_water_sensor = true;
        }
        else {
            full_water_sensor = false;
        }

        if (pondage >= 320) {
            water_level_sensor_4 = true;
            
        }
        else {
            water_level_sensor_4 = false;
        }

        if (pondage >= 220) {
            water_level_sensor_3 = true;
        }
        else {
            water_level_sensor_3 = false;
        }

        if (pondage >= 120) {
            water_level_sensor_2 = true;
        }
        else {
            water_level_sensor_2 = false;
        }

        if (pondage >=  20) {
            water_level_sensor_1 = true;
        }
        else {
            water_level_sensor_1 = false;
        }
    }
}
