package pot;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Lamp extends JPanel {
    private JLabel   name;
    private LampPart lamp;
    Lamp(String name) {
        super(new FlowLayout());
        this.lamp = new LampPart();
        this.name = new JLabel(name);

        add(this.lamp);
        add(this.name);
    }

    void setLamp(boolean bool) {
        lamp.setLamp(bool);
    }
}
