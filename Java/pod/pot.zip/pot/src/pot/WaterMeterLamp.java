package pot;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class WaterMeterLamp extends JPanel {
    private Color off;
    private Color on;
    private boolean sensor[];

    private static final int xpoints[][] = {
        { 0, 20, 20,  0},
        { 0, 20, 20,  0},
        { 0, 20, 20,  0},
        { 0, 20, 20,  0},
    };
    private static final int ypoints[][] = {
        {75, 75, 95, 95},
        {50, 50, 70, 70},
        {25, 25, 45, 45},
        { 0,  0, 20, 20},
    };

    WaterMeterLamp() {
        this(Color.lightGray, Color.green, false, false, false, false);
    }

    WaterMeterLamp(Color off, Color on, boolean one, boolean two, boolean three, boolean four) {
        this.off     = off;
        this.on      = on;

        this.sensor = new boolean[4];
        this.sensor[0] = one;
        this.sensor[1] = two;
        this.sensor[2] = three;
        this.sensor[3] = four;

        setMinimumSize(new Dimension(20, 95));
    }

    void setSensor(int sensor_no, boolean bool) {
        sensor[sensor_no - 1] = bool;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int i = 0; i < 4; i++) {
            if (sensor[i]) {
                g.setColor(on);
            }
            else {
                g.setColor(off);
            }
            g.fillPolygon(xpoints[i], ypoints[i], 4);
        }
    }
}
